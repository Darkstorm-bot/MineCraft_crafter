from __future__ import annotations

import yaml


def load_redstone_templates(path: str = "configs/redstone_components.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}
